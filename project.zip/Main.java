package kr.co.ksist.cinema.myPage;

import java.util.Scanner;

public class Main {
	private static UI ui;
	private static Scanner scan;
	
	static {
		ui = new UI();
		scan = new Scanner(System.in);
	}
	
	public static void main(String[] args) {
		boolean loop = true;
		ui.begin();
	}
}
