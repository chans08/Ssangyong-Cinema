package kr.co.ksist.cinema.myPage;

public class FilePath {
	public static final String MEMBER = "";
}
