package kr.co.ksist.cinema.myPage;

public class UI {
	
	public static final int MEMBERSHIPINFO = 1;
	public static final int RESERVATEIONCONFIRMCANCLE = 2;
	public static final int MYPURCHASEHISTORY = 3;
	public static final int PURSONALINFORMMODI = 4;
	public static final int MYENQUIARYDETAILS = 5;
	public static final int RETURNTOHOME = 0;
	
	public void begin() {
		System.out.println("[회원정보]");
//		System.out.println("%s님\t\t| %s\n", name, grade);
//		System.out.println("멤버십 포인트\t\t %s\n", point);
//		System.out.println("멤버십 등급\t\t %s\n", grade);
	}

	
	//System.out.println("[메뉴]");
}
