package kr.co.sist.cinema.manager_snackstore;

public class FilePath {
	public final static String SNACKSTORE = "D:\\class\\java\\cinema\\data\\store.dat";
	public final static String SNACKNUMBERING = "D:\\class\\java\\cinema\\data\\snacknumbering.dat";
			
}