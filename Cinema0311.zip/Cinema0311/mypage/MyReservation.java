package kr.co.sist.cinema.mypage;

public class MyReservation {

}
