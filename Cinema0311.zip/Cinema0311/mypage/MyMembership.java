package kr.co.sist.cinema.mypage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class MyMembership {

	public static final String PATH_MEMBER = "D:\\java\\Cinema\\src\\data\\member.dat";
	public static final String PATH_RESERVATION = "D:\\java\\Cinema\\src\\data\\reservaton.dat";

	private static ArrayList<Member> listMember;
	private static ArrayList<Reservation> listReservation;
	private static Scanner scan;
	private static Calendar c;

	static {
		listMember = new ArrayList<Member>();
		listReservation = new ArrayList<Reservation>();
		scan = new Scanner(System.in);
		c = Calendar.getInstance();
	}

	private String id;

	public MyMembership(String id) {
		this.id = id;
	}

	/**
	 * 간략한 멤버십 정보를 출력하는 메소드
	 */
	public void info() {
		for (int i = 0; i < listMember.size(); i++) {
			if (listMember.get(i).getId().equals(id)) {
				System.out.println();
				System.out.print("[멤버십 정보]  ");
				System.out.printf("%s님은 '%s %s' 회원입니다.\n", listMember.get(i).getName(), thisYear(), listMember.get(i).getGrade());
				selectMenu();
				break;
			}
		}
	}

	public String thisYear() {
		String thisYear = c.get(Calendar.YEAR) + "";
		return thisYear;
	}

	/**
	 * myMembership에서 선택가능한 메뉴를 보여주는 메소드
	 */
	public void menu() {
		System.out.println("========================================");// 40개
		System.out.println("1. 포인트 현황 (현재 보유, 소멸 예정 포인트)");
		System.out.printf("현재 보유 포인트 %,15dp\n", Integer.parseInt(point()));
		System.out.println("2. 멤버십 카드 정보 (카드 등록 및 해지)");
		System.out.println("[나의 카드]");
		System.out.println("----------------------------------------");
		System.out.println("카드명		카드번호		발급일");
		System.out.println("----------------------------------------");
		System.out.printf("%s\n", mycard());
		System.out.println("0. 이전 메뉴로 돌아가기");
		System.out.println("========================================");
		System.out.print("선택(번호) : ");
	}

	public String point() {
		for (int i = 0; i < listMember.size(); i++) {
			if (listMember.get(i).getId().equals(id)) {
				return listMember.get(i).getPoint();
			}
		}
		return "아이디정보없음";
	}

	private String mycard() {
		for (int i = 0; i < listMember.size(); i++) {
			if (listMember.get(i).getId().equals(id)) {
				if (Boolean.parseBoolean(listMember.get(i).getIsRegisted())) {
					String cardName = listMember.get(i).getCardName();
					String cardNum = listMember.get(i).getCardNum();
					String issuedDate = listMember.get(i).getIssuedDate();
					String result = String.format("%s\t%s\t%s\n", cardName, cardNum, issuedDate);
					return result;
				} else {
					return "등록된 카드가 없습니다. 등록하시려면 '2'를 입력하세요.";
				}
			}
		}
		return "아이디정보없음";
	}

	/**
	 * 선택한 멤버십 정보 메뉴를 불러오는 메소드
	 */
	public void selectMenu() {
		boolean loop = true;
		while (loop) {
			menu();
			switch (scan.nextLine()) {
			case "1":
				pointStatusMenu();
				break;
			case "2":
				membershipCardInfo();
				break;
			case "0":
				loop = false;
				break;
			default:
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
				break;
			}
		}
	}

	private void membershipCardInfo() {
		// TODO Auto-generated method stub
		
	}

	private void pointStatusMenu() {
		System.out.println();
		System.out.println("[포인트 현황]");
		System.out.printf("현재 보유 포인트 %,10dp\n", Integer.parseInt(point()));
		System.out.printf("소멸 예정일 %10s일\n", dDay());
		System.out.printf("(%s년 12월 31일 영업 종료시)\n", thisYear());
		System.out.println("========================================");
		System.out.println("1. 포인트 내역 조회");
		System.out.println("2. 소멸 예정일이란?");
		System.out.println("0. 이전 메뉴로 돌아가기");
		System.out.println("========================================");
		System.out.print("선택(번호) : ");
		System.out.println();
		selectPointStatusMenu();
	}

	private String dDay() {
		int dDay = 0;
		for (int i = 0; i<listReservation.size(); i++) {
			if (listReservation.get(i).getId().equals(id)) {
				int y = Integer.parseInt(thisYear());
				c.set(y, 11, 31);
				long endOfYearTick = c.getTime().getTime();
				long nowTick = System.currentTimeMillis();
				long tick = endOfYearTick - nowTick;
				dDay = (int) (tick / 1000 / 60 / 60 / 24);
				break;
			}
		}
		return "-" + dDay;
	}
	
	private void selectPointStatusMenu() {
		boolean loop = true;
		while (loop) {
			switch (scan.nextLine()) {
			case "1":
				pointDetails();
				break;
			case "2":
				expectedToPerish();
				break;
			case "0":
				loop = false;
				break;
			default:
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
				break;
			}
		}
	}
	
	private void pointDetails() {
		System.out.println();
		System.out.println("[포인트 내역 조회]  전체 | 적립 | 사용 | 소멸");
		System.out.println("-----------------------------------------------------");
		System.out.println("일자		지점	이용내용		이용금액	적립포인트	사용포인트	구분");
		System.out.println("-----------------------------------------------------");
		for (int i=0; i<listReservation.size(); i++) {
			if (listReservation.get(i).getId().equals(id)) {
				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\n"
						, listReservation.get(i).getReservationDate()
						, listReservation.get(i).getTheater().equals(1) ? "강남" 
								: listReservation.get(i).getTheater().equals(2) ? "강북"
								: listReservation.get(i).getTheater().equals(3) ? "관악"
								: listReservation.get(i).getTheater().equals(4) ? "잠실" : "홍대"
						, "티켓구입(10%적립) - " + listReservation.get(i).getTitle()
						, String.format("%,d원", Integer.parseInt(listReservation.get(i).getPrice()))
						, String.format("%,d", Integer.parseInt(listReservation.get(i).getOccuredPoint()))
						, listReservation.get(i).getUsedPoint().equals("0") ? "" : String.format("-%,d", Integer.parseInt(listReservation.get(i).getUsedPoint()))
						, sortation(i));
			}
		}
	}

	private String sortation(int i) {
		int y = Integer.parseInt(listReservation.get(i).getReservationDate().substring(0, 4));
		int m = Integer.parseInt(listReservation.get(i).getReservationDate().substring(5, 7));
		int d = Integer.parseInt(listReservation.get(i).getReservationDate().substring(8, 10));
		c.set(y, m, d);
		long reservationDateTick = c.getTime().getTime();
		c.set(c.get(Calendar.YEAR) - 1, 11, 31);
		long endOfLastYearTick = c.getTime().getTime();
		if (reservationDateTick <= endOfLastYearTick) {
			return "소멸";
		} else if (listReservation.get(i).getUsedPoint().equals("0")) {
			return "적립";
		} else {
			return "사용";
		}
	}

	private void expectedToPerish() {
		System.out.println("[소멸 예정일]");
		System.out.printf("회원님의 %s년 12월 31일 소멸예정 디데이는 %s입니다.\n", thisYear(), dDay());
		System.out.println("(현재 시각 기준)");
		System.out.println("▶ 소멸예정일이란?");
		System.out.println("  쌍용 적립 포인트의 유효기간은 최초 적립시점인 해당 년 말일이며, \r\n해당 기간 안에 사용 하지 못한 잔여포인트가 그 해 말일 영업 \r\n종료 후 소멸 됩니다.");
		System.out.println();
	}

	/**
	 * ArrayList<Member> list에 회원정보 담기
	 */
	public void loadMember() {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(PATH_MEMBER));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] temp = line.split("■");
				Member m = new Member(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7], temp[8],
						temp[9], temp[10], temp[11], temp[12], temp[13], temp[14], temp[15], temp[16]);
				listMember.add(m);
			}
			reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}

	/**
	 * ArrayList<Reservation> list에 예약정보 담기
	 */
	public void loadReservation() {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(PATH_RESERVATION));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] temp = line.split("■");
				Reservation r = new Reservation(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7],
						temp[8], temp[9], temp[10], temp[11], temp[12], temp[13]);
				listReservation.add(r);
			}
			reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}

}