package dummy;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class CountByCondition {
	public static void main(String[] args) {
		//각 상태별로 영화 몇갠지 세기
		try {
			BufferedReader reader = new BufferedReader(new FileReader("D:\\java\\Dummy\\src\\data\\cutMovieInfo.dat"));
			ArrayList<String> list = new ArrayList<String>();
			int scheduled = 0;
			int onScreen = 0;
			int charged = 0;
			int forFree = 0;
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] temp = line.split("■");
				//1상태(1:개봉예정,2:상영중,3:유료,4:무료)
				if (temp[1].equals("1")) {
					scheduled++;
				} else if (temp[1].equals("2")) {
					onScreen++;
				} else if (temp[1].equals("3")) {
					charged++;
				} else if (temp[1].equals("4")) {
					forFree++;
				} 
				
				//list.add(line);
			}
			reader.close();
			
			System.out.printf("scheduled : %d\n", scheduled);
			System.out.printf("onScreen : %d\n", onScreen);
			System.out.printf("charged : %d\n", charged);
			System.out.printf("forFree : %d\n", forFree);
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
