package dummy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//import Cinema.src.kr.co.sist.cinema.mypage.FilePath;
import java.util.Calendar;
import java.util.Random;

//추가//|관리자식별|멤버십 카드번호|멤버십 발급일|
public class AddInfoDummy {
	public static void main(String[] args) throws IOException {
		
		String txt = addDummy();
		write(txt);
		
	}//main

	private static String addDummy() {
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader("D:\\java\\Dummy\\src\\data\\member.dat"));
			
			String txt = "";
			String line = null;
			int i=1;
			while ((line = reader.readLine()) != null) {
				
				Calendar c = Calendar.getInstance();
				long nowTick = System.currentTimeMillis();
				c.set(2000, 0, 1);
				long setTick = c.getTime().getTime();
				long tick = nowTick - setTick;
				int d = (int)(tick / 1000 / 60 / 60 / 24);
				
				Random rnd = new Random();
				int addDate = rnd.nextInt(d) + 1;
				c.add(Calendar.DATE, addDate);
				String date = String.format("%tF", c);
				
				int[] gBasic = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3 }; 
				int g = gBasic[rnd.nextInt(gBasic.length)];
				
				
				//txt += line + String.format("%s■7127-1400-2323-%04d■%s■%s■\r\n", rnd.nextInt(2) == 0 ? "false" : "true", i, date, g == 0 ? "일반" : g == 1 ? "VIP" : g == 2 ? "VIP PREMIUM" : "VVIP");
				txt += line + String.format("%b■%s■%s■\r\n", rnd.nextInt(2) == 0 ? "false" : "true", date, "쌍용회원전용카드");
				i++;
			}
			reader.close();
			
			return txt;
			
		} catch (Exception e) {
			System.out.println(e.toString());
			
			return "잘못됨";
		}
	}

	
	private static void write(String txt) throws IOException {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\java\\Dummy\\src\\data\\member.dat"));
			
			writer.write(txt);
			writer.close();
			System.out.println("작성완료.");
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}	
}
