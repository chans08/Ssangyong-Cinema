package dummy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class ChangeIdentifier {
	public static void main(String[] args) {
		try {
		
			BufferedReader reader = new BufferedReader(new FileReader("D:\\class\\java\\Cinema\\src\\data\\member.dat"));
			
			String line = null;
			String txt = "";
			while ((line = reader.readLine()) != null) {
				txt += line + "\r\n";
			}
			
			txt = txt.replace("\t", "■");
			
			BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\class\\java\\Cinema\\src\\data\\member.dat"));
			writer.write(txt);
			
			writer.close();
			
			System.out.println("교체완료");
			System.out.println(txt);
			
		} catch (Exception e) {
			System.out.println("");
			System.out.println(e.toString());
		}
		
		
		
	}
}
