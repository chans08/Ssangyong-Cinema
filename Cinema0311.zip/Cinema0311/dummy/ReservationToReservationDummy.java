package dummy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Random;
//id, 예매번호까지 생성해주는 클래스
public class ReservationToReservationDummy {
	
	public static final String WRITE_PATH = "D:\\java\\Dummy\\src\\data\\reservationToReservationNum.dat";
	public static final String MEMBER_PATH = "D:\\java\\Cinema\\src\\data\\member.dat";
	public static final String MOVIE_INFO_PATH = "D:\\java\\Dummy\\src\\data\\cutMovieInfo.dat";
	
	public static final int PERIOD = 3;// PERIOD = 3개월((현재 년월일 + 7일)의 3개월 전 년월일 ~ 현재 년월일 + 7일) 
	public static final int ON_SCREEN =28;// ON_SCREEN = 현재 상영중 영화 개수
	public static void main(String[] args) {
		
		int count = 0;// count = member.dat라인수
		try {
			BufferedReader reader = new BufferedReader(new FileReader(MEMBER_PATH));
				String line = null;
				while ((line = reader.readLine()) != null) {
					count++;
				}
		} catch (Exception e) {
			System.out.println(e.toString());
		}	
		
		String id[] = new String[count];
		String reservationNum[] = new String[count];
		
		//회원id들 String[] id에 차곡차곡 넣기
		try {
			BufferedReader reader = new BufferedReader(new FileReader(MEMBER_PATH));
				String line = null;
				int i = 0;
				while ((line = reader.readLine()) != null) {
					String[] temp = line.split("■");
					id[i] = temp[0];
					i++;
				}
				reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		
		Random rnd = new Random();
		String movieNum = "";
		
		
		//예매번호 생성 기초작업
		String[] r1 = new String[28];//28 = 상영 중 영화 개수
		String[] r2 = new String[5];//5 = 상영관 개수
		String[] r4 = new String[50];//50 = 좌석번호 개수		
		
		int max = 1028;//상영중 영화 개수  + 다시보기 제공 영화 개수(1=최초 다시보기 영화, 2= 두번째로 업로드된 다시보기 영화, ... , 1028=마지막으로 업로드된 최근 상영 영화) 
		int n1 = 1028 - ON_SCREEN * 1;//ON_SCREEN = 28(한달에 상영해주는 영화 개수)// n1 = 1000
		int n2 = 1028 - ON_SCREEN * 2;// n2 = 972
		int n3 = 1028 - ON_SCREEN * PERIOD;// n3 = 944
		
		for (int i=0; i<count; i++) {		
			Calendar c = Calendar.getInstance();
			String tF = d();
			int y = Integer.parseInt(tF.substring(0, 4));
			int temp = Integer.parseInt(tF.substring(5, 7));
			int d = Integer.parseInt(tF.substring(8, 10));
			c.set(y, temp, d);
			c.add(Calendar.MONTH, - 1);//d()의 년월일로 Calendar 설정
			long fromTick = c.getTime().getTime();
			c = Calendar.getInstance();
			c.add(Calendar.DATE, 7);
			long toTick = c.getTime().getTime();
			long tick = toTick - fromTick;
			int dN = (int)(tick / 1000 / 60 / 60 / 24);//현재+7일 후와 예매일 사이의 일수
			
			//영화상태
			String[] scheduled = new String[11];
			String[] onScreen = new String[7];
			String[] chargedOrForFree = new String[20];
			
			try {//movieInfo.dat load하기
				BufferedReader reader = new BufferedReader(new FileReader(MOVIE_INFO_PATH));
					String line = null;
					int j1 = 0, j2 = 0, j3 = 0;
					while ((line = reader.readLine()) != null) {
						String[] temp1 = line.split("■");
						if (temp1[1].equals("1")) {
							scheduled[j1] = temp1[0];
							j1++;
						} else if (temp1[1].equals("2")) {
							onScreen[j2] = temp1[0];
							j2++;
						} else if (temp1[1].equals("3") || temp1[1].equals("4")) {
							chargedOrForFree[j3] = temp1[0];
							j3++;
						} 
					}
					reader.close();
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			if (dN <= 7) {//개봉예정 영화이면
				movieNum = scheduled[rnd.nextInt(scheduled.length)];
			} else if (dN <= 30) {
				movieNum = onScreen[rnd.nextInt(onScreen.length)];
			} else {
				movieNum = chargedOrForFree[rnd.nextInt(chargedOrForFree.length)];
			}
			
			String yS = (y + "").substring(2, 4);//19
			String tempS = String.format("%02d", temp);//03
			String dS = String.format("%02d", d);//10
			String date = yS + tempS + dS;//예매일//190310
			
			reservationNum[i] = movieNum + "-"
								+ (rnd.nextInt(r2.length) + 1) + "-" 
								+ date + "-"
								+ (rnd.nextInt(r4.length) + 1) + "";
		}
			
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(WRITE_PATH));
			
			for (int i=0; i<count; i++) {
				writer.write(String.format("%s■%s■\r\n"
						, id[i]
						, reservationNum[i]));
			}
			
			writer.close();
			
			System.out.println("완료");
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//main
	
	public static String d() {//d() = 현시점으로부터 3개월 전 + 7일 부터 ~ 현재 + 7일 의 어느 연월일
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 7);
		long toTick = c.getTime().getTime();
		c.add(Calendar.MONTH, - 3);
		long fromTick = c.getTime().getTime();
		long tick = toTick - fromTick;
		int d = (int)(tick / 1000 / 60 / 60 / 24);
		Random rnd = new Random();
		int addDate = rnd.nextInt(d) + 1;
		c.add(Calendar.DATE, addDate);
		String date = String.format("%tF", c);

		return date;
	}
	
	public static String date() {//"2019-03-10" -> "190310"
		String d = d();
		String[] temp = d.split("-");
		String d2 = temp[0] + temp[1] + temp[2];
		String date = d2.substring(2, d2.length());
		
		return date;
	}
}


