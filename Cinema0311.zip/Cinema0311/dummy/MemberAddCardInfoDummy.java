package dummy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.Random;

public class MemberAddCardInfoDummy {
	public static void main(String[] args) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader("D:\\java\\Dummy\\src\\data\\member.dat"));
			String txt = "";
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] temp = line.split("■");
				String regiDate = temp[12];//regiDate = "2010-11-11"
				String[] temp2 = regiDate.split("-");
				int y = Integer.parseInt(temp2[0]);// y = 2010
				int m = Integer.parseInt(temp2[1]);// m = 11
				int d = Integer.parseInt(temp2[2]);// d = 11
				
				String issuedDate = "0";// issuedDate = "카드발급년월일"
				
				Calendar c = Calendar.getInstance();
				c.set(y, m, d);
				long regTick = c.getTime().getTime();// regTick = 1970년부터 등록일까지의 틱값 
				Random rnd = new Random();
				String isReg = rnd.nextInt(2) == 0 ? "false" : "true";
				boolean flag = Boolean.parseBoolean(isReg);
				if (flag) {//등록되어 있었으면
					while (true) {
						//랜덤으로 2000년부터 지금 사이의 년월일(date) 뽑기
						c = Calendar.getInstance();
						long nowTick = System.currentTimeMillis();
						c.set(2000, 0, 1);
						long setTick = c.getTime().getTime();
						long temp3 = nowTick - setTick;
						int temp4 = (int)(temp3 / 1000 / 60 / 60 / 24);
						int addDate = rnd.nextInt(temp4) + 1;
						c.add(Calendar.DATE, addDate);
						String date = String.format("%tF", c);// date = "2001-01-01"(2000년도보다 지난 년월일)
						long DateTick = c.getTime().getTime();
						if (DateTick >= regTick) {
							issuedDate = date;
							break;
						}
					}//while
				} else {
					issuedDate = "0";
				}
				txt += line + String.format("%s■%s■%s■\r\n", isReg, issuedDate, "쌍용회원전용카드");
			}
			reader.close();

			BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\java\\Dummy\\src\\data\\member.dat"));
		
			writer.write(txt);
			writer.close();
			System.out.println("작성완료.");
		
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}
}

