package dummy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

//reservationNum 부터 시작해서 reservation.dat 완성하는 class
public class ReservationAfterReservationNumDummy {
	public static final String WRITE_PATH = "D:\\java\\Dummy\\src\\data\\reservaton.dat";
	public static final String COUNT_MEMBER_LINE_PATH = "D:\\java\\Dummy\\src\\data\\member.dat";
	public static final String MOVIE_INFO_PATH = "D:\\java\\Dummy\\src\\data\\movieInfo.dat";
	public static final String RESERVATION_PATH = "D:\\java\\Dummy\\src\\data\\reservationToReservationNum.dat";
	
	
	public static void main(String[] args) throws IOException {
		String txt = addDummy();
		write(txt);
		
	}//main

	private static void write(String txt) throws IOException {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(WRITE_PATH));
			
			writer.write(txt);
			writer.close();
			System.out.println("작성완료.");
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}	

	private static String addDummy() {
		String txt = "";
		int count = 0;// count = member.dat라인 개수
		try {
			BufferedReader reader = new BufferedReader(new FileReader(COUNT_MEMBER_LINE_PATH));
				String line = null;
				while ((line = reader.readLine()) != null) {
					count++;
				}
		} catch (Exception e) {
			System.out.println(e.toString());
		}	
		
		String title[] = new String[count];
		String showDate[] = new String[count];
		String showtime[] = new String[count];
		String theater[] = new String[count];
		String seat[] = new String[count];
		String price[] = new String[count];
		String reservationDate[] = new String[count];
		String isIssued[] = new String[count];
		String isExpired[] = new String[count];
		String cancelDate[] = new String[count];
		String occuredPoint[] = new String[count];
		String usedPoint[] = new String[count];
		
		String[] show = { "08:40", "12:10", "15:40", "19:10", "22:40" };
		
		ArrayList<String> list = new ArrayList<String>();
		ArrayList<String> listTitle = new ArrayList<String>();
		ArrayList<String> listSerialNum = new ArrayList<String>();
		
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(RESERVATION_PATH));
				int i = 0;
				String line = null;
				while ((line = reader.readLine()) != null) {
					list.add(line);
					String[] temp = line.split("■");//temp = {id, reservationNum}
					String[] temp1 = temp[1].split("-");//temp1 = {serialNum, theater, showDate, seat}
					showDate[i] = "20" + temp1[2].substring(0, 2) + "-" + temp1[2].substring(2, 4) + "-" + temp1[2].substring(4, 6);
					theater[i] = temp1[1];
					seat[i] = temp1[3];
					i++;
				}
				reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		try {
			String line = null;
			BufferedReader reader = new BufferedReader(new FileReader(MOVIE_INFO_PATH));
				while ((line = reader.readLine()) != null) {
					String[] temp = line.split("■");
					listSerialNum.add(temp[0]);
					listTitle.add(temp[2]);
					
				}
				reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader(RESERVATION_PATH));
			String line = null;
			for (int i=0; i<list.size(); i++) {
				for (int j=0; j<list.size(); j++) {
					String[] temp = list.get(i).split("■");//temp = {id, reservationNum}
					String[] temp1 = temp[1].split("-");//temp1 = {serialNum, theater, showDate, seat}
					
					if (temp1[0].equals(listSerialNum.get(j))) {
						title[i] = listTitle.get(j);
						break;
					}
				}
				//영화명
				//title[i] = ;OK
				
				//상영일시
				//showDate[i] = ;OK
				
				//상영시작시간
				Random rnd = new Random();
				showtime[i] = show[rnd.nextInt(show.length)];
				
				//영화관
				//theater[i] = ;OK
				
				//좌석정보
				//seat[i] = ;OK
						
				//가격
				if (showtime[i].equals(show[0])) {
					price[i] = "6000";
				} else {
					price[i] = "10000";
				}
					
				//예매일 : 상영일로부터 7일전부터 상영일 하루 전까지 예매 가능
				Calendar c = Calendar.getInstance();
				
				int y = Integer.parseInt(showDate[i].substring(0, 4));//showDate : 상영일
				int m = Integer.parseInt(showDate[i].substring(5, 7));
				int d = Integer.parseInt(showDate[i].substring(8, 10));
				
				c.set(y, m, d);
				c.add(Calendar.MONTH, -1);
				long showDateTick = c.getTime().getTime();
				c.add(Calendar.DATE, -7);
				long fromTick = c.getTime().getTime();
				long t = showDateTick - fromTick;
				int addD = (int)(t / 1000 / 60 / 60 / 24);
				c.add(Calendar.DATE, rnd.nextInt(addD));
				long reservationDateTick = c.getTime().getTime();
				
				reservationDate[i] = String.format("%tF", c);
				
				//티켓 발급 여부
				isIssued[i] = rnd.nextInt(2) == 0 ? "0" : "1";
				
				//기한만기여부
				c = Calendar.getInstance();
				long nowTick = c.getTime().getTime();
				long tick = showDateTick - nowTick;
							
				if (tick >= 0) {
					isExpired[i] = "0";
				} else {
					isExpired[i] = "1";
				}
				
				//취소일시 : 예매일과 상영일 하루전 사이에 취소 가능
				c.set(y, m, d);
				c.add(Calendar.MONTH, -1);
				c.add(Calendar.DATE, -7);
				int addD2 = (int)((showDateTick - reservationDateTick) / 1000 / 60 / 60 / 24);
				c.add(Calendar.DATE, addD2);
				
				int[] temp = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
				int flag = temp[rnd.nextInt(temp.length)];
				if (flag == 0) {
					cancelDate[i] = "0";
				} else {
					cancelDate[i] = String.format("%tF", c);
				}
				
				//예매발생 포인트
				occuredPoint[i] = String.format("%.0f", Integer.parseInt(price[i]) * 0.1);
				
				//사용 포인트
				usedPoint[i] = "0";
				
				line = reader.readLine();
				txt += line + String.format("%s■%s■%s■%s■%s■%s■%s■%s■%s■%s■%s■%s■\r\n"
						, title[i]
						, showDate[i]
						, showtime[i]
						, theater[i]
						, seat[i]
						, price[i]
						, reservationDate[i]
						, isIssued[i]
						, isExpired[i]
						, cancelDate[i]
						, occuredPoint[i]
						, usedPoint[i]);
				
			}//for
			reader.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return txt;
	}
}
	

